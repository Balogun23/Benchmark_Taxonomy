# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_4")

if (!requireNamespace("pryr", quietly = TRUE)) install.packages("pryr")
library(pryr)

# Load dataset
df <- read.csv("../birth_gp_ratios.csv")

# Track total lines of code in the script
script_path <- "t_test_task.R"
if (file.exists(script_path)) {
  total_loc <- length(readLines(script_path))
} else {
  total_loc <- NA
  warning("Script file not found. LOC count failed.")
}

# --------------------- BENCHMARK STARTS HERE ---------------------
start_time  <- Sys.time()
cpu_start   <- proc.time()
mem_before  <- mem_used()

# --- Core Task: T-test comparing actual_births between 2015 and 2016 ---
df_actual <- subset(df, ratio_type == "actual")
df_actual$date <- as.character(df_actual$date)  # Ensure it's character if date parsing is inconsistent

group1 <- subset(df_actual, date == "01/01/2015")$actual_births
group2 <- subset(df_actual, date == "01/01/2016")$actual_births

group1 <- group1[!is.na(group1)]
group2 <- group2[!is.na(group2)]

if (length(group1) > 1 && length(group2) > 1) {
  test_result <- t.test(group1, group2, var.equal = FALSE)
  cat("T-test Result:\n")
  print(test_result)
} else {
  cat("Not enough data to perform t-test.\n")
}

# --------------------- BENCHMARK ENDS HERE ---------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS ---------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 5  # subset, filter, drop NA, t-test, print

# --------------------- OUTPUT ---------------------
cat("\n T-test task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
