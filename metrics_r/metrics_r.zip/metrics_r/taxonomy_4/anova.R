# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_1")

if (!requireNamespace("pryr", quietly = TRUE)) install.packages("pryr")
library(pryr)

df <- read.csv("../birth_gp_ratios.csv")

script_path <- "anova_task.R"
if (file.exists(script_path)) {
  total_lines_of_code <- length(readLines(script_path))
} else {
  total_lines_of_code <- NA
  warning("Script file not found. LOC count failed.")
}

# --------------------- BENCHMARK STARTS HERE ---------------------
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# --- Core Task: Run ANOVA if groups by 'date' have >= 2 observations ---
df_filt <- subset(df, ratio_type == "actual" & !is.na(actual_births))

# Count non-NA values per date
group_counts <- table(df_filt$date)
valid_dates <- names(group_counts[group_counts >= 2])

# Subset to only those valid dates
df_valid <- subset(df_filt, date %in% valid_dates)

# Check if enough groups to run ANOVA
if (length(unique(df_valid$date)) >= 2) {
  result <- oneway.test(actual_births ~ date, data = df_valid, var.equal = TRUE)
  cat("ANOVA Result:\n")
  print(result)
} else {
  cat("Cannot run ANOVA: Not enough valid groups\n")
}

# --------------------- BENCHMARK ENDS HERE ---------------------
mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()

# Compute metrics
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)

# Core task lines: 6
core_task_lines <- 6

# Output
cat("ANOVA task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_lines_of_code, "\n")
cat("Lines of Core Task Only:", core_task_lines, "\n")

