# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_4")

# Ensure pryr is available for memory tracking
if (!requireNamespace("pryr", quietly = TRUE)) install.packages("pryr")
library(pryr)

# Load the dataset once, outside the benchmark
df <- read.csv("../birth_gp_ratios.csv")

# Script name for total-LOC counting
script_path <- "correlation_task.R"
if (file.exists(script_path)) {
  total_loc <- length(readLines(script_path))
} else {
  total_loc <- NA                  # fallback if you run interactively
  warning("Script file not found for LOC count.")
}

# --------------------- BENCHMARK STARTS HERE ---------------------
start_time  <- Sys.time()
cpu_start   <- proc.time()
mem_before  <- mem_used()

# --- Core Task: Pearson correlation between actual_births & gp_count ----
df_clean <- subset(
  df,
  ratio_type == "actual" & !is.na(actual_births) & !is.na(gp_count)
)

corr_matrix <- cor(
  df_clean[, c("actual_births", "gp_count")],
  method = "pearson"              # change to "spearman" if desired
)

cat("Correlation matrix:\n")
print(corr_matrix)

# --------------------- BENCHMARK ENDS HERE ---------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS ---------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_mb      <- round((mem_after - mem_before) / 1024^2, 3)

core_loc <- 3     # clean, correlate, print

# --------------------- OUTPUT ---------------------
cat("\n Correlation task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
