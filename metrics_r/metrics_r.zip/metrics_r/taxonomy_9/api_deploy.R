suppressPackageStartupMessages({library(pryr); library(processx); library(httr)})
script_path <- "api_service.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA
core_loc  <- 5

start_time <- Sys.time(); cpu_start <- proc.time(); mem_before <- pryr::mem_used()

port <- 8788
code <- sprintf('suppressPackageStartupMessages(library(plumber));
pr <- pr(); pr <- pr_get(pr, "/ping", function(){ list(status="ok") });
pr$run(host="127.0.0.1", port=%d, swagger=FALSE)', port)

px <- processx::process$new("Rscript", c("-e", code), stdout="|", stderr="|", windows_verbatim_args=TRUE)
on.exit(try(px$kill(), silent=TRUE), add=TRUE)

base <- sprintf("http://127.0.0.1:%d/ping", port)
ok <- FALSE
for (i in 1:120) { res <- try(httr::GET(base, timeout(0.5)), silent=TRUE)
if (!inherits(res, "try-error") && httr::status_code(res)==200L) { ok <- TRUE; break }
Sys.sleep(0.1) }
if (!ok) stop("API did not start in time.")

invisible(httr::GET(base, timeout(2)))

end_time <- Sys.time(); cpu_end <- proc.time(); mem_after <- pryr::mem_used()
runtime <- round(as.numeric(difftime(end_time, start_time, "secs")),3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]],3)
mem_used_mb <- round((mem_after - mem_before)/1024^2,3)

cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
