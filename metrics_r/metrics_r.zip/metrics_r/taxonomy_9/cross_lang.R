suppressPackageStartupMessages({library(pryr); library(reticulate)})
script_path <- "interop_driver.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA
core_loc  <- 5

# reticulate::use_python("C:/Path/To/python.exe", required=TRUE)  # if needed

start_time <- Sys.time(); cpu_start <- proc.time(); mem_before <- pryr::mem_used()

if (!reticulate::py_available(initialize=TRUE)) stop("No Python detected by reticulate.")
reticulate::py_run_string("
def agg(n):
    s = 0
    for i in range(n):
        s += i
    return s
")
res <- reticulate::py$agg(500000)

end_time <- Sys.time(); cpu_end <- proc.time(); mem_after <- pryr::mem_used()
runtime <- round(as.numeric(difftime(end_time, start_time, "secs")),3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]],3)
mem_used_mb <- round((mem_after - mem_before)/1024^2,3)

cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Result (Python agg):", format(res, scientific=FALSE), "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
