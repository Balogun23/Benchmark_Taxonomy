suppressPackageStartupMessages({library(pryr); library(processx); library(httr)})
script_path <- "shiny_app.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA
core_loc  <- 5

start_time <- Sys.time(); cpu_start <- proc.time(); mem_before <- pryr::mem_used()

port <- 8789
app_code <- sprintf(
  'suppressPackageStartupMessages(library(shiny));
   ui <- fluidPage(h2("Benchmark Dashboard"), plotOutput("p"));
   server <- function(input, output, session) {
     output$p <- renderPlot({ barplot(c(3,1,2), names.arg=c("A","B","C")) })
   }
   shiny::runApp(list(ui=ui, server=server),
                 host="127.0.0.1", port=%d, launch.browser=FALSE)', port)

px <- processx::process$new("Rscript", c("-e", app_code), stdout="|", stderr="|", windows_verbatim_args=TRUE)
on.exit(try(px$kill(), silent=TRUE), add=TRUE)

base <- sprintf("http://127.0.0.1:%d", port)
ok <- FALSE
for (i in 1:150) { res <- try(httr::GET(base, timeout(0.5)), silent=TRUE)
if (!inherits(res, "try-error") && httr::status_code(res)==200L) { ok <- TRUE; break }
Sys.sleep(0.1) }
if (!ok) stop("Shiny app did not start in time.")

invisible(httr::GET(base, timeout(2)))

end_time <- Sys.time(); cpu_end <- proc.time(); mem_after <- pryr::mem_used()
runtime <- round(as.numeric(difftime(end_time, start_time, "secs")),3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]],3)
mem_used_mb <- round((mem_after - mem_before)/1024^2,3)

cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
