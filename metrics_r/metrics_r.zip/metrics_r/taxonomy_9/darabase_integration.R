library(DBI); library(RSQLite)
con <- dbConnect(RSQLite::SQLite(), ":memory:")
dbWriteTable(con, "t", data.frame(id=1:10))
dbGetQuery(con, "SELECT COUNT(*) FROM t")


suppressPackageStartupMessages({library(pryr); library(DBI); library(RSQLite)})
script_path <- "db_pipeline.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA
core_loc  <- 5

start_time <- Sys.time(); cpu_start <- proc.time(); mem_before <- pryr::mem_used()

con <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
on.exit(try(DBI::dbDisconnect(con), silent=TRUE), add=TRUE)
DBI::dbExecute(con, "CREATE TABLE t (id INTEGER, name TEXT)")
dat <- data.frame(id=1:100000, name=sprintf("Name_%d", 1:100000), stringsAsFactors=FALSE)
DBI::dbWriteTable(con, "t", dat, append=TRUE)
n <- DBI::dbGetQuery(con, "SELECT COUNT(*) AS n FROM t")$n[1]

end_time <- Sys.time(); cpu_end <- proc.time(); mem_after <- pryr::mem_used()
runtime <- round(as.numeric(difftime(end_time, start_time, "secs")),3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]],3)
mem_used_mb <- round((mem_after - mem_before)/1024^2,3)

cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Rows in table:", n, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
