suppressPackageStartupMessages({library(pryr); library(data.table)})
script_path <- "scalability_task.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA
core_loc  <- 5

start_time <- Sys.time(); cpu_start <- proc.time(); mem_before <- pryr::mem_used()

n <- 1e6
DT <- data.table(id = seq_len(n), value = seq_len(n))
DT[, squared := value^2L]
rows <- nrow(DT)

end_time <- Sys.time(); cpu_end <- proc.time(); mem_after <- pryr::mem_used()
runtime <- round(as.numeric(difftime(end_time, start_time, "secs")),3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]],3)
mem_used_mb <- round((mem_after - mem_before)/1024^2,3)

cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Rows processed:", rows, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
