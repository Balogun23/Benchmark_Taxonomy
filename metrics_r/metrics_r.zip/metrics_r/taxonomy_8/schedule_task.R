# ---------------- SETUP (Not Benchmarked) -------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_8")

library(pryr)

script_path <- "schedule_task.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# ---------------- BENCHMARK START --------------------------
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# ---------------- CORE TASK: Simulated Scheduling ----------
run_job <- function() {
  cat("Running scheduled job...\n")
}

for (i in 1:3) {
  run_job()
  Sys.sleep(1)  # simulate a 1-second interval
}

# ---------------- BENCHMARK END ----------------------------
end_time <- Sys.time()
cpu_end <- proc.time()
mem_after <- mem_used()

# ---------------- METRICS ----------------------------------
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc <- 3  # 1. run_job, 2. loop, 3. sleep

# ---------------- OUTPUT -----------------------------------
cat("Simulated scheduled task completed.\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
