# ------------------ SETUP (Not Benchmarked) --------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_8")

pkgs <- c("data.table", "pryr")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(data.table)
library(pryr)

script_path <- "pipeline.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# ------------------ BENCHMARK START ---------------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# ------------------ FULL PIPELINE CORE ------------------------
df <- fread("../birth_gp_ratios.csv")
df <- df[ratio_type == "actual" & !is.na(actual_births) & !is.na(gp_count)]

model <- lm(actual_births ~ gp_count, data = df)
df$prediction <- predict(model, newdata = df)

fwrite(df[, .(gss_name, gp_count, actual_births, prediction)], "pipeline_report.csv")
cat("Regression report saved as 'pipeline_report.csv'\n")

# ------------------ BENCHMARK END -----------------------------
end_time <- Sys.time()
cpu_end   <- proc.time()
mem_after <- mem_used()

# ------------------ METRICS -----------------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 5  # load, filter, model, predict, export

# ------------------ OUTPUT ------------------------------------
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
