# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_8")

pkgs <- c("pryr", "data.table")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, dependencies = TRUE)
library(pryr)
library(data.table)

script_path <- "error_handling.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK START ---------------------
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# --------------------- SAFE TASK CORE ---------------------
success <- FALSE
attempts <- 0

while (!success && attempts < 3) {
  tryCatch({
    df <- fread("../birth_gp_ratios.csv")
    cat("Data loaded successfully.\n")
    success <- TRUE
  }, error = function(e) {
    attempts <- attempts + 1
    cat(sprintf("Attempt %d failed: %s\n", attempts, e$message))
    Sys.sleep(1)
  })
}

# --------------------- BENCHMARK END ---------------------
mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()

# --------------------- METRICS -----------------------------
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc <- 5  # 3 logic lines in loop + fread + message

# --------------------- OUTPUT ------------------------------
cat("\n Safe task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
