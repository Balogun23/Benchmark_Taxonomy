# ------------------ SETUP (Not Benchmarked) --------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_8")

pkgs <- c("pryr", "data.table")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(pryr)
library(data.table)

script_path <- "logging_task.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# ------------------ BENCHMARK START ---------------------------
start_time_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
cat("Started at:", start_time_str, "\n")

start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# ------------------ LOGGING TASK CORE -------------------------
success <- FALSE
tryCatch({
  df <- fread("../birth_gp_ratios.csv")
  success <- TRUE
}, error = function(e) {
  cat("Error:", e$message, "\n")
})

end_time <- Sys.time()
end_time_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
cpu_end <- proc.time()
mem_after <- mem_used()

# ------------------ METRICS -----------------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 5  # fread, tryCatch, time logging, runtime calc, success flag

# ------------------ OUTPUT -------------------------------------
cat("Ended at:", end_time_str, "\n")
cat("Success:", success, "\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
