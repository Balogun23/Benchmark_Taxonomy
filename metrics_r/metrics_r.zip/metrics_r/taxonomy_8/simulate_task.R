# ------------------- SETUP (Not Benchmarked) -------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_8")

library(pryr)

script_path <- "simulate_dag.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# ------------------- BENCHMARK START --------------------------
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# ------------------- CORE TASK --------------------------------
tasks <- c("Extract", "Clean", "Model", "Report")
for (t in tasks) {
  cat(t, " → ", sep = "")
  Sys.sleep(0.5)
}
cat("Done\n")

# ------------------- BENCHMARK END ----------------------------
end_time <- Sys.time()
cpu_end <- proc.time()
mem_after <- mem_used()

# ------------------- METRICS ----------------------------------
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc <- 3  # loop, print, and sleep

# ------------------- OUTPUT -----------------------------------
cat("DAG simulation completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
