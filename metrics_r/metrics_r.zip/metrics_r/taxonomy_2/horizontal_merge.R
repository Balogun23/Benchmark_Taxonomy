setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_2")

if (!requireNamespace("pryr", quietly = TRUE)) {
  install.packages("pryr")
}
library(pryr)


main <- read.csv("../birth_gp_ratios.csv")


script_path <- "horizontal_merge.R"
if (file.exists(script_path)) {
  total_lines_of_code <- length(readLines(script_path))
} else {
  total_lines_of_code <- NA
  warning("Script file not found. LOC count failed.")
}


start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()


gss_codes <- unique(na.omit(main$gss_code))[1:10]
dummy_lookup <- data.frame(
  gss_code = gss_codes,
  region_group = paste0("Group_", seq_along(gss_codes))
)

merged <- merge(main, dummy_lookup, by = "gss_code", all.x = TRUE)
write.csv(merged, "merged_with_lookup.csv", row.names = FALSE)


mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()


runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)


core_task_lines <- 3


cat("erged with dummy region_group on gss_code\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script_path):", total_lines_of_code, "\n")
cat("Lines of Core Task Only:", core_task_lines, "\n")
