setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_1")


if (!requireNamespace("pryr", quietly = TRUE)) {
  install.packages("pryr")
}
library(pryr)


df <- read.csv("../birth_gp_ratios.csv")


script_path <- "handle_missing_data.R"
if (file.exists(script_path)) {
  total_lines_of_code <- length(readLines(script_path))
} else {
  total_lines_of_code <- NA
  warning("Script file not found. LOC count failed.")
}


start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# --- Core Task: Drop rows with missing gp_count or actual_births ---
df_cleaned <- subset(df, !is.na(gp_count) & !is.na(actual_births))
write.csv(df_cleaned, "cleaned_missing.csv", row.names = FALSE)


mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()


runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)


core_task_lines <- 2


cat("removed missing values from gp_count and actual_births\n")
cat("Remaining rows:", nrow(df_cleaned), "\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_lines_of_code, "\n")
cat("Lines of Core Task Only:", core_task_lines, "\n")
