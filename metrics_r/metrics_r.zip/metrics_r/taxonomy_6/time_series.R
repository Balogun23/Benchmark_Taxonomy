# ---------------- SETUP ----------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_6")  # Adjust to your path

pkgs <- c("data.table", "ggplot2", "pryr", "lubridate")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(data.table)
library(ggplot2)
library(pryr)
library(lubridate)

# Calculate total lines of code in this script
script_path <- "time_series.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# ---------------- BENCHMARK START ----------------
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# --------------- Core Task -----------------------
df <- fread("../birth_gp_ratios.csv")
df_filtered <- df[ratio_type == "actual" & sex == "persons"]

df_filtered[, date := as.Date(date, format = "%d/%m/%Y")]
df_plot <- df_filtered[, .(actual_births = sum(actual_births, na.rm = TRUE)), by = date]

p <- ggplot(df_plot, aes(x = date, y = actual_births)) +
  geom_line(color = "steelblue") +
  labs(title = "Time Series of Births",
       x = "Year", y = "Actual Births") +
  theme_minimal()

ggsave("time_series_plot.png", p, width = 7, height = 5)
cat("Chart saved to:", normalizePath("time_series_plot.png"), "\n")

# ---------------- BENCHMARK END ------------------
mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()

# ---------------- METRICS ------------------------
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc <- 4  # read-filter, group, plot, save

# ---------------- OUTPUT -------------------------
cat("\n Time series task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script_path):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
