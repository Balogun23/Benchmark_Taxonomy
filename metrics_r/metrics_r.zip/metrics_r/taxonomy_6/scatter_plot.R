# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_6")   # adjust if needed

pkgs <- c("pryr", "ggplot2", "data.table", "viridis")  # viridis for colour scale
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, dependencies = TRUE)
library(pryr)
library(ggplot2)
library(data.table)
library(viridis)

# Helper: total lines of code
script_path <- "scatter_plot_task.R"
total_loc   <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK START ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --- Core Task: Filter data & scatter plot -----------------
df <- fread("../birth_gp_ratios.csv")
df_scatter <- df[ratio_type == "actual" &
                   !is.na(actual_births) &
                   !is.na(gp_count)]

plot <- ggplot(df_scatter, aes(x = gp_count,
                               y = actual_births,
                               colour = actual_births)) +
  geom_point() +
  scale_colour_viridis_c(option = "viridis") +
  labs(title = "Scatter Plot of Births vs GP Count",
       x = "GP Count",
       y = "Actual Births",
       colour = "Actual Births") +
  theme_minimal()

print(plot)                                # Show in RStudio
ggsave("scatter_coloured.png", plot = plot, width = 7, height = 5)
cat("Chart saved to:", normalizePath("scatter_coloured.png"), "\n")

# --------------------- BENCHMARK END -----------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS -----------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 4   # filter, plot, print, save

# --------------------- OUTPUT ------------------------------
cat("\n Scatter plot task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")


