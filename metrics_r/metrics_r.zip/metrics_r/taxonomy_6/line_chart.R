# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_6")

pkgs <- c("pryr", "ggplot2", "data.table")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, dependencies = TRUE)
library(pryr)
library(ggplot2)
library(data.table)

# Helper: total lines of code in this script
script_path <- "line_chart_task.R"
total_loc   <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK START ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --- Core Task: Filter, group, line plot -------------------
df <- fread("../birth_gp_ratios.csv")
df_line <- df[ratio_type == "actual" & sex == "persons",
              .(actual_births = sum(actual_births, na.rm = TRUE)),
              by = date]

plot <- ggplot(df_line, aes(x = as.factor(date), y = actual_births, group = 1)) +
  geom_line(color = "red", linewidth = 1) +
  geom_point(color = "red") +
  labs(title = "Line Chart of Births Over Time",
       x = "Date", y = "Births") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

print(plot)   # Display in RStudio
ggsave("line_chart.png", plot = plot, width = 8, height = 5)
cat("Chart saved to:", normalizePath("line_chart.png"), "\n")

# --------------------- BENCHMARK END -----------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS -----------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 4   # filter/group, plot, print, save

# --------------------- OUTPUT ------------------------------
cat("\n Line chart task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
