# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_6")

pkgs <- c("pryr", "ggplot2", "data.table")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, dependencies = TRUE)
library(pryr)
library(ggplot2)
library(data.table)

# Helper: total LOC
script_path <- "histogram.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK START ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --- Core Task: Filter data & plot histogram ----------------
df <- fread("../birth_gp_ratios.csv")
df_hist <- df[ratio_type == "actual" & !is.na(actual_births)]

plot <- ggplot(df_hist, aes(x = actual_births)) +
  geom_histogram(bins = 20, fill = "darkorange", color = "black") +
  labs(title = "Histogram of Actual Births",
       x = "Births", y = "Frequency") +
  theme_minimal()

print(plot)                                   # shows in RStudio
ggsave("histogram.png", plot = plot, width = 7, height = 5)
cat("📁 Chart saved to:", normalizePath("histogram.png"), "\n")

# --------------------- BENCHMARK END -----------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS -----------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 4   # filter, plot, print, save

# --------------------- OUTPUT ------------------------------
cat("\n✅ Histogram task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
