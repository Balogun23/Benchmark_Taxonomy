# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_6")   # adjust if needed

pkgs <- c("pryr", "ggplot2", "data.table")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, dependencies = TRUE)
library(pryr)
library(ggplot2)
library(data.table)

# Line-count helper
count_lines <- function(path) if (file.exists(path)) length(readLines(path)) else NA
script_path <- "boxplot_task.R"
total_loc   <- count_lines(script_path)

# --------------------- BENCHMARK START ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --- Core Task: Filter & make boxplot --------------------------------
df <- fread("../birth_gp_ratios.csv")
df_plot <- df[ratio_type == "actual" & !is.na(actual_births)]

plot <- ggplot(df_plot, aes(x = "", y = actual_births)) +
  geom_boxplot(fill = "skyblue") +
  labs(title = "Boxplot of Actual Births", y = "Births", x = NULL) +
  theme_minimal()

print(plot)                                     # show in RStudio
ggsave("boxplot.png", plot = plot, width = 5, height = 6)
cat("📁 Chart saved to:", normalizePath("boxplot.png"), "\n")

# --------------------- BENCHMARK END ---------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS --------------------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 4   # filter, ggplot, print, save

# --------------------- OUTPUT ---------------------------------------
cat("\n✅ Boxplot task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
