# ---------------------- SETUP ----------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_6")  # adjust path if needed

if (!requireNamespace("pryr", quietly = TRUE)) install.packages("pryr")
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
library(pryr)
library(ggplot2)

# ---------------------- LOAD DATA ----------------------
df <- read.csv("../birth_gp_ratios.csv")

# ---------------------- BENCHMARK START ----------------------
start_time  <- Sys.time()
cpu_start   <- proc.time()
mem_before  <- mem_used()

# ---------------------- CORE TASK ----------------------
df_filtered <- subset(df, ratio_type == "actual" & sex == "persons")
df_grouped  <- aggregate(actual_births ~ date, data = df_filtered, sum)

plot <- ggplot(df_grouped, aes(x = date, y = actual_births)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  labs(title = "Bar Chart of Births Over Time",
       x = "Date", y = "Actual Births") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Show chart in RStudio
print(plot)

# Save chart as PNG
ggsave("bar_chart.png", plot = plot, width = 8, height = 5)
cat("Chart saved to:", normalizePath("bar_chart.png"), "\n")

# ---------------------- BENCHMARK END ----------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# ---------------------- METRICS ----------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 4  # filtering, grouping, plotting, saving

# ---------------------- OUTPUT ----------------------
cat("\n Bar chart task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
