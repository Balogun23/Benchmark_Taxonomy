# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_5")

pkgs <- c("pryr", "caret", "glmnet")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, dependencies = TRUE)
library(pryr)
library(caret)
library(glmnet)

df <- read.csv("../birth_gp_ratios.csv", stringsAsFactors = FALSE)

script_path <- "gridsearch_task.R"
total_loc   <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK STARTS HERE ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --- Core Task: Grid-search logistic regression ------------------
df_clean <- subset(df,
                   ratio_type == "actual" &
                     !is.na(actual_births) &
                     !is.na(gp_count))

# Binary target
median_birth <- median(df_clean$actual_births, na.rm = TRUE)
df_clean$high_birth <- as.integer(df_clean$actual_births > median_birth)

# Matrix with intercept added manually
X <- as.matrix(cbind(Intercept = 1, gp_count = df_clean$gp_count))
y <- df_clean$high_birth

ctrl <- trainControl(method = "cv", number = 3)

lambda_grid <- c(10, 1, 0.1)
tune <- expand.grid(alpha = 0, lambda = lambda_grid)

set.seed(42)
model <- train(
  x = X,
  y = as.factor(y),
  method = "glmnet",
  trControl = ctrl,
  tuneGrid = tune,
  family = "binomial"
)

cat("Best λ (lambda):", model$bestTune$lambda, "\n")

# --------------------- BENCHMARK ENDS HERE ---------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS --------------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 7  # Clean, binarise, matrix, ctrl, grid, model, print

# --------------------- OUTPUT --------------------------------
cat("\n✅ Grid-search logistic regression task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
