# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_5")

if (!requireNamespace("pryr", quietly = TRUE)) install.packages("pryr")
library(pryr)

script_path <- "model_saving_task.R"
total_loc   <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK STARTS HERE ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --- Core Task: Save and load logistic regression model ----------
model <- glm(high_birth ~ gp_count, data = data.frame(
  gp_count = c(1, 2, 3, 4, 5, 6),
  high_birth = c(0, 1, 0, 1, 0, 1)
), family = binomial)

saveRDS(model, "logistic_model.rds")
loaded_model <- readRDS("logistic_model.rds")

cat("✅ Model saved and reloaded successfully.\n")

# --------------------- BENCHMARK ENDS HERE ---------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS --------------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 3  # model + saveRDS + readRDS

# --------------------- OUTPUT --------------------------------
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
