# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_4")

# Packages for benchmarking and modelling
if (!requireNamespace("pryr",    quietly = TRUE)) install.packages("pryr")
if (!requireNamespace("caTools", quietly = TRUE)) install.packages("caTools")
if (!requireNamespace("brglm2",  quietly = TRUE)) install.packages("brglm2")

library(pryr)
library(caTools)
library(brglm2)     # bias-reduced GLMs

# Load dataset
df <- read.csv("../birth_gp_ratios.csv", stringsAsFactors = FALSE)

# Track total lines of code in this script
script_path <- "logistic_task_brglm.R"
total_loc   <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK STARTS HERE ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --- Core Task: Bias-reduced logistic model ----------------------
df <- subset(df,
             ratio_type == "actual" &
               !is.na(actual_births) &
               !is.na(gp_count))

median_birth  <- median(df$actual_births, na.rm = TRUE)
df$high_birth <- as.integer(df$actual_births > median_birth)

set.seed(42)
split <- sample.split(df$high_birth, SplitRatio = 0.7)
train <- subset(df,  split)
test  <- subset(df, !split)

# Use brglm2's bias-reduction (Firth)
brglmFit <- brglm2::brglmFit
model <- glm(high_birth ~ gp_count,
             data   = train,
             family = binomial("logit"),
             method = brglmFit)

# Predictions
prob_pred <- predict(model, newdata = test, type = "response")
y_pred    <- ifelse(prob_pred > 0.5, 1, 0)

# Accuracy and confusion matrix
accuracy <- mean(y_pred == test$high_birth)
conf_mat <- table(Predicted = y_pred, Actual = test$high_birth)

cat("Accuracy:", round(accuracy, 3), "\n")
cat("Confusion Matrix:\n"); print(conf_mat)

# --------------------- BENCHMARK ENDS HERE -----------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS -----------------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 9   # filter, target, split, model, predict, cutoff, accuracy, table, print

# --------------------- OUTPUT ------------------------------------
cat("\n Bias-reduced logistic regression task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
