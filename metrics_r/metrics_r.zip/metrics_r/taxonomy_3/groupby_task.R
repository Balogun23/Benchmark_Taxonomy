setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_3")

if (!requireNamespace("pryr", quietly = TRUE)) {
  install.packages("pryr")
}
library(pryr)

df <- read.csv("../birth_gp_ratios.csv")

script_path <- "groupby_task.R"
if (file.exists(script_path)) {
  total_lines_of_code <- length(readLines(script_path))
} else {
  total_lines_of_code <- NA
  warning("Script file not found. LOC count failed.")
}

start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

grouped_summary <- aggregate(
  actual_births ~ sex,
  data = df,
  FUN = function(x) c(mean = mean(x, na.rm = TRUE),
                      sum = sum(x, na.rm = TRUE),
                      count = sum(!is.na(x)))
)

cat("Grouped Summary by 'sex':\n")
print(grouped_summary)

mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()

runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)

core_task_lines <- 2

cat("Grouped summary calculation completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script_path):", total_lines_of_code, "\n")
cat("Lines of Core Task Only:", core_task_lines, "\n")
