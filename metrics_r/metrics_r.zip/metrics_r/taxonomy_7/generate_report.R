# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_7") 

pkgs <- c("data.table", "pryr", "htmltools", "utils")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(data.table)
library(pryr)
library(htmltools)

# Total lines in script
script_path <- "report_task.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# --------------------- BENCHMARK START ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --------------------- CORE TASK ---------------------------
df <- fread("../birth_gp_ratios.csv")
desc_summary <- summary(df)

# Convert summary to HTML and save
html_summary <- paste(capture.output(print(desc_summary)), collapse = "<br>")
report <- paste("<h1>Descriptive Report</h1>", html_summary)

writeLines(report, "report.html")
cat("📁 Descriptive report saved as report.html\n")

# --------------------- BENCHMARK END -----------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS -----------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 3   # read, summary, write

# --------------------- OUTPUT ------------------------------
cat("\n✅ Report task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
