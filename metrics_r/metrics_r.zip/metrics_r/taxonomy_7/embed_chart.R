# ----------------- SETUP -----------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_7")  

pkgs <- c("data.table", "ggplot2", "pryr")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(data.table)
library(ggplot2)
library(pryr)

# Line count for the current file
script_path <- "embed_chart.R"
total_loc <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# ----------------- BENCHMARK START -----------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# ----------------- CORE TASK -----------------
df <- fread("../birth_gp_ratios.csv")
df <- df[ratio_type == "actual" & !is.na(actual_births)]
df <- df[, .(actual_births = sum(actual_births, na.rm = TRUE)), by = date]

# Plot and save chart
p <- ggplot(df, aes(x = as.Date(date), y = actual_births)) +
  geom_line(color = "darkred") +
  labs(title = "Trend of Births", x = "Year", y = "Births") +
  theme_minimal()

ggsave("trend_chart.png", p, width = 7, height = 5)

# Embed chart into HTML
html <- c(
  "<h1>Trend of Actual Births</h1>",
  "<img src='trend_chart.png' width='600'>"
)
writeLines(html, "chart_report.html")
cat("Chart embedded into chart_report.html\n")

# ----------------- BENCHMARK END -----------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# ----------------- METRICS -----------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 5  # read, filter, group, plot, write HTML

# ----------------- OUTPUT -----------------
cat("\n Embed task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
