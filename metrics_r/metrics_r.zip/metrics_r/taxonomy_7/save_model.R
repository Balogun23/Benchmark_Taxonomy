# ------------------- SETUP --------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_7") 

pkgs <- c("pryr")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(pryr)

# ------------------- BENCHMARK START --------------------
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# ------------------- CORE TASK --------------------
model <- glm(vs ~ mpg, data = mtcars, family = binomial)  # logistic regression on sample data
saveRDS(model, "saved_model.rds")
loaded_model <- readRDS("saved_model.rds")

cat("Model saved and reloaded.\n")

# ------------------- BENCHMARK END --------------------
mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()

# ------------------- METRICS --------------------
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc <- 3  # fit, saveRDS, readRDS

# ------------------- OUTPUT --------------------
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
