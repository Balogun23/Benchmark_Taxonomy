# ---------------------- SETUP (Not Benchmarked) ----------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_7") 

pkgs <- c("data.table", "openxlsx", "pryr")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(data.table)
library(openxlsx)
library(pryr)

# Total lines of code in this script
script_path <- "export_task.R"
total_loc   <- if (file.exists(script_path)) length(readLines(script_path)) else NA

# ---------------------- BENCHMARK START -----------------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# ---------------------- CORE TASK -----------------------------------
df <- fread("../birth_gp_ratios.csv")
df_summary <- df[, .(actual_births = sum(actual_births, na.rm = TRUE)), by = date]

fwrite(df_summary, "summary_export.csv")
write.xlsx(df_summary, "summary_export.xlsx")

cat("Exported: summary_export.csv and summary_export.xlsx\n")

# ---------------------- BENCHMARK END -------------------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# ---------------------- METRICS -------------------------------------
runtime     <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time    <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)
core_loc    <- 4  # read, summarise, write CSV, write XLSX

# ---------------------- OUTPUT --------------------------------------
cat("\n Export task completed\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_loc, "\n")
cat("Lines of Core Task Only:", core_loc, "\n")
