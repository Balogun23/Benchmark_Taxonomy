# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_1")

# Load required packages
if (!requireNamespace("pryr", quietly = TRUE)) {
  install.packages("pryr")
}
library(pryr)

# Load dataset (outside benchmarking)
df <- read.csv("../birth_gp_ratios.csv")

# Script file path for LOC tracking
script_path <- "indexing.R"
if (file.exists(script_path)) {
  total_lines_of_code <- length(readLines(script_path))
} else {
  total_lines_of_code <- NA
  warning("⚠️ Script file not found. LOC count failed.")
}

# Benchmark start
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# Ensure unique row names from gss_code
df$gss_index <- paste0(df$gss_code, "_", seq_len(nrow(df)))
row.names(df) <- df$gss_index
df$gss_code <- NULL
df$gss_index <- NULL

write.csv(df, "indexed_data.csv", row.names = TRUE)

# Benchmark end
mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()

# Compute Metrics
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)

# Core LOC: 2 lines → setting rownames + writing to CSV
core_task_lines <- 2

# Output Results
cat("✅ Indexed Data by 'gss_code'\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script_path):", total_lines_of_code, "\n")
cat("Lines of Core Task Only:", core_task_lines, "\n")
