# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_1")

# Load required packages
if (!requireNamespace("pryr", quietly = TRUE)) {
  install.packages("pryr")
}
library(pryr)

# Load dataset (outside benchmarking)
df <- read.csv("../birth_gp_ratios.csv")

# Script file path for LOC tracking
script_path <- "filtering.R"
if (file.exists(script_path)) {
  total_lines_of_code <- length(readLines(script_path))
} else {
  total_lines_of_code <- NA
  warning("⚠️ Script file not found. LOC count failed.")
}

# --------------------- BENCHMARK START ---------------------
start_time <- Sys.time()
cpu_start  <- proc.time()
mem_before <- mem_used()

# --------------------- CORE TASK: FILTERING ---------------------
# Example filter: keep rows with actual_births > 1000
filtered_df <- subset(df, actual_births > 1000)

# Persist result
write.csv(filtered_df, "filtered_data.csv", row.names = FALSE)

# --------------------- BENCHMARK END -----------------------
mem_after <- mem_used()
cpu_end   <- proc.time()
end_time  <- Sys.time()

# --------------------- METRICS ------------------------------
runtime    <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_delta  <- cpu_end - cpu_start
cpu_time   <- round(unname(cpu_delta[["user.self"]] + cpu_delta[["sys.self"]]), 3)  # CPU (user+sys)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)

# Core LOC: 2 lines → (1) filtering, (2) writing CSV
core_task_lines <- 2

# --------------------- OUTPUT -------------------------------
cat("✅ Filtered Data (actual_births > 1000)\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script_path):", total_lines_of_code, "\n")
cat("Lines of Core Task Only:", core_task_lines, "\n")
