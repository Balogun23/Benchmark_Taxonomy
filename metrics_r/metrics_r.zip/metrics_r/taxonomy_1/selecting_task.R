# --------------------- SETUP (Not Benchmarked) ---------------------
setwd("C:/Users/HP/Downloads/metrics_r/taxonomy_1")

# Load required package
if (!requireNamespace("pryr", quietly = TRUE)) {
  install.packages("pryr")
}
library(pryr)

# Script file for total lines of code
script_path <- "select_columns_task.R"
if (file.exists(script_path)) {
  total_lines_of_code <- length(readLines(script_path))
} else {
  total_lines_of_code <- NA
  warning("Script file not found. LOC count failed.")
}

# --------------------- BENCHMARK STARTS HERE ---------------------
start_time <- Sys.time()
cpu_start <- proc.time()
mem_before <- mem_used()

# --- Core Task: Read full CSV and select columns ---
df <- read.csv("../birth_gp_ratios.csv")
selected <- df[, c("gss_name", "gp_count", "actual_births", "date")]
write.csv(selected, "selected_columns.csv", row.names = FALSE)

# --------------------- BENCHMARK ENDS HERE ---------------------
mem_after <- mem_used()
cpu_end <- proc.time()
end_time <- Sys.time()

# Compute metrics
runtime <- round(as.numeric(difftime(end_time, start_time, units = "secs")), 3)
cpu_time <- round((cpu_end - cpu_start)[["user.self"]], 3)
mem_used_mb <- round((mem_after - mem_before) / 1024^2, 3)

# Core task LOC: 3 lines — read, select, write
core_task_lines <- 3

# Output results
cat("Selected columns and saved to selected_columns.csv\n")
cat("Selected rows:", nrow(selected), "\n")
cat("Runtime (seconds):", runtime, "\n")
cat("CPU Time (seconds):", cpu_time, "\n")
cat("Memory usage (MB):", mem_used_mb, "\n")
cat("Total Lines of Code (script):", total_lines_of_code, "\n")
cat("Lines of Core Task Only:", core_task_lines, "\n")
